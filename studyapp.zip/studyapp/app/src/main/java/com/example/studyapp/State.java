package com.example.studyapp;

public class State {

    private String name; // название предмета
    private String name_two;  // преподователь
    private String auditory;  // кабинет
    private int flagResource; // фон

    public State(String name, String capital, String auditory, int flag){

        this.name=name;
        this.name_two =capital;
        this.auditory=auditory;
        this.flagResource=flag;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName_two() {
        return this.name_two;
    }

    public void setName_two(String name_two) {
        this.name_two = name_two;
    }

    public String getAuditory() {
        return this.auditory;
    }

    public void setAuditory(String auditory) {
        this.auditory = auditory;
    }

    public int getFlagResource() {
        return this.flagResource;
    }

    public void setFlagResource(int flagResource) {
        this.flagResource = flagResource;
    }
}